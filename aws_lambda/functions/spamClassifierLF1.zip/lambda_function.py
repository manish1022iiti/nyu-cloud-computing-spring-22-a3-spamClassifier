import os
import json
import boto3
from botocore.exceptions import ClientError
import email
from bs4 import BeautifulSoup
from sms_spam_classifier_utilities import one_hot_encode
from sms_spam_classifier_utilities import vectorize_sequences

ENDPOINT_NAME = os.environ["ENDPOINT_NAME"]


def read_s3_email_file(bucket, fname):
    print(f"bucket: {bucket}, fname: {fname}")

    # reading email contents from s3 bucket
    s3_client = boto3.client("s3")
    file_content = s3_client.get_object(Bucket=bucket, Key=fname)["Body"].read().decode("utf-8")

    # reading email's key details
    msg = email.message_from_string(file_content)
    from_addr = msg["from"]
    to_addr = msg["to"]
    msg_date = msg["date"]
    msg_sub = msg["subject"]
    msg_body = list()

    # reading message body
    if msg.is_multipart():
        for part in msg.get_payload():
            msg_body.append(part.get_payload())
    else:
        msg_body.append(msg.get_payload())
    msg_body = ". ".join(msg_body)
    # removing html tags from msg body
    msg_body = BeautifulSoup(msg_body).get_text()
    # removing \r\n chars from msg body
    msg_body = msg_body.replace("\n", "").replace("\r", "")

    ret = dict()
    ret["from"] = from_addr
    ret["to"] = to_addr
    ret["date"] = msg_date
    ret["subject"] = msg_sub
    ret["body"] = msg_body

    print(f"message details: {ret}")
    return ret


def classify_email(msg):
    # doing one-hot encoding of the input message
    vocabulary_length = 9013
    msgs = [msg]
    one_hot_test_messages = one_hot_encode(msgs, vocabulary_length)
    encoded_test_messages = vectorize_sequences(one_hot_test_messages, vocabulary_length)

    # getting prediction from sagemaker
    runtime = boto3.client("runtime.sagemaker")
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       Body=json.dumps(encoded_test_messages.tolist()))
    print(f"response from Sagemaker: {response}")

    # decoding sagemaker results
    result = json.loads(response["Body"].read())
    print(f"parsed result: {result}")

    return result["predicted_label"][0][0], result["predicted_probability"][0][0]


def frame_response_message_to_the_sender(edata):
    msg = [f"We received your email sent at '{edata['date']}' with subject '{edata['subject']}'.",
           f"Here is a 240 character sample of the email body: {edata['body'][:240]}.",
           f"The email was categorized as {edata['category']} with a {edata['confidence'] * 100}% confidence."]
    return "\n".join(msg)


def send_email_to_the_sender(email_data):
    SENDER = email_data["to"]
    RECIPIENT = email_data["from"]

    # If necessary, replace us-west-2 with the AWS Region you're using for Amazon SES.
    AWS_REGION = "us-east-1"

    # The subject line for the email.
    SUBJECT = f"Re: {email_data['subject']}"

    # The email body for recipients with non-HTML email clients.
    BODY_TEXT = (f"{email_data['response']}")

    # The HTML body of the email.
    BODY_HTML = f"""<html>
    <head></head>
    <body>
      <p>{email_data['response']}</p>
    </body>
    </html>
                """

    # The character encoding for the email.
    CHARSET = "UTF-8"

    # Create a new SES resource and specify a region.
    client = boto3.client('ses', region_name=AWS_REGION)

    # Try to send the email.
    try:
        # Provide the contents of the email.
        response = client.send_email(
            Destination={
                'ToAddresses': [
                    RECIPIENT
                ],
            },
            Message={
                'Body': {
                    'Html': {
                        'Charset': CHARSET,
                        'Data': BODY_HTML,
                    },
                    'Text': {
                        'Charset': CHARSET,
                        'Data': BODY_TEXT,
                    },
                },
                'Subject': {
                    'Charset': CHARSET,
                    'Data': SUBJECT,
                },
            },
            Source=SENDER,
            # # If you are not using a configuration set, comment or delete the
            # # following line
            # ConfigurationSetName=CONFIGURATION_SET,
        )
    # Display an error if something goes wrong.
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print(f"Email sent! Message ID: {response['MessageId']}"),


def lambda_handler(event, context):
    # TODO implement
    print(f"event: {event}")

    # extracting bucket and filename
    fdata = event["Records"][0]
    bucket = fdata["s3"]["bucket"]["name"]
    key = fdata["s3"]["object"]["key"]

    # reading email file and predicting spam/not-spam and confidence value
    edata = read_s3_email_file(bucket=bucket, fname=key)
    category, confidence = classify_email(msg=edata["body"])
    # category, confidence = classify_email(msg="I am testing this message for spam!")

    # framing response message
    edata["category"] = category
    edata["confidence"] = confidence
    edata["response"] = frame_response_message_to_the_sender(edata)
    print(f"response message body: {edata['response']}")

    send_email_to_the_sender(email_data=edata)

    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }
